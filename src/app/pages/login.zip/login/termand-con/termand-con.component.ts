import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termand-con',
  templateUrl: './termand-con.component.html',
  styleUrls: ['./termand-con.component.scss']
})
export class TermandConComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
