/*Login*/

import { TermandConComponent } from './termand-con/termand-con.component';
import { GeneralService } from './../../services/genservice.service';
import { AuthModel } from './../../model/auth.model';
import { GenModel } from './../../model/gen.model';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { emailValidator, matchingPasswords } from '../../theme/utils/app-validators';
import { AppSettings } from '../../app.settings';
import { Settings } from '../../app.settings.model';
import { MatSnackBar } from '@angular/material';
import { LocalStorageModule } from 'angular-2-local-storage';
import { LocalStorageService } from 'angular-2-local-storage';
import Swal from 'sweetalert2';
import { resetFakeAsyncZone } from '@angular/core/testing';
import { List } from 'linqts';
import { MatDialog } from '@angular/material/dialog';
import { LoginResponse } from '../../model/loginResponse.model';
import { AlertifyService } from '../../services/alertify.service';
import { SweetAlertService } from '../../services/sweetAlert.service';
import { ThrowStmt } from '@angular/compiler';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public form: FormGroup;
  public formSignUp: FormGroup;

  hideLoginBack = GenModel.hideLoginBack;

  version = GenModel.Version;

  public settings: Settings;
  durationsnack: number = 3000;
  displayloader: boolean = false;
  btnlogtxt: string = 'SIGN IN';
  religionlist = [
    'Muslim',
    'Christianity'
  ];

  tokenExpiryTime = GenModel.tokenExpiryTime;
  tokenCheckTimeInterval = GenModel.tokenCheckTimeInterval;
  loginSucc = false;

  userName = AuthModel.userName;
  password = AuthModel.password;
  token = GenModel.tokenName;
  retryService: number = GenModel.retryService;
  retryMessage: any;
  retryDelayServiceInterval: number = GenModel.retryDelayServiceInterval;
  internetConMsg = GenModel.internetConMsg;

  userLoginInfo = GenModel.userLoginInfo;
  btnConfirm = GenModel.btnConfirm;
  errorOccur = GenModel.errorOccur;
  loginRoleId = GenModel.loginRoleId;
  encryptKey = GenModel.EncryptKey;
  roles: any[];
  roleMorethan1 = false;
  selectedRoleId: any;
  displayloaderRole = false;
  btnlogtxtContine = 'Continue';
  btn = 'SIGN UP';
  role = GenModel.role;
  showLogin = false;
  showSignUp = false;
  hideLogin = true;

  imgId = 0;

  hide = true;

  loadTimeDif = 6000;
  apiIsDown = GenModel.apiIsDown;
  loginResponse: LoginResponse;

  constructor(public appSettings: AppSettings,
    public fb: FormBuilder,
    public fbSignUp: FormBuilder,
    public router: Router,
    private route: ActivatedRoute,
    public snackBar: MatSnackBar,
    private storage: LocalStorageService,
    public _GeneralService: GeneralService,
    public dialog: MatDialog,
    private alertify: AlertifyService,
    private sweetAlertService: SweetAlertService

  ) {

    this.settings = this.appSettings.settings;

    this.loginResponse = new LoginResponse();

    this.clientProfile();

    this.form = this.fb.group({
      userName: [null, Validators.compose([Validators.required])],
      password: [null, Validators.compose([Validators.required])]
    });


  }

  openDialog() {
    const dialogRef = this.dialog.open(TermandConComponent);

    dialogRef.afterClosed().subscribe(result => {

    });
  }


  ngOnInit() {

    this.settings.loadingSpinner = true;
    this._GeneralService.clearAllLocalStorage();
    this.router.navigate(['.']);

  }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  public clientProfile(): any {


    let url = 'Licence/License';

    let values = {
      userName: "",
      password: ""
    }

    this.loginSucc = true;

    this._GeneralService.login(values, url)
      .subscribe((data: any) => {

        this.loginSucc = false;
        this.loginResponse = data._response;

        console.log('this.loginResponse: ', this.loginResponse);

        if (this.loginResponse.errorCode === -1000) {

          this.licenseExpires(this.loginResponse.errorMessage)
          return;
        }

      },
        (error: any) => {

          console.log('error Login', error);


        });

  }

  test() {
    this.alertify.success('test()');
  }

  public TestForAlert(values: any): any {

    /*
     The commented below is for AlertifyJs alert, if Ok button is clicked, the the test() will be called
    this.alertify.confirm('Are you sure you want to delete this photo', () => {
      this.test();
    });
    */
    // The commented below is for Sweet alert, if Ok button is clicked, the the test() will be called
    this.sweetAlertService.confirm("title", "alert Text", "Yes, Continue", "Cancel", () => {
      this.test();
    });

  }
  public onSubmit(values: any): any {

    console.log('onSubmit values: ', values);
    let trackRetryAPi = 0;
    let url = 'Authentication/AAuth';


    console.log('url values: ', url);


    this.btnlogtxt = 'Authenticating...';

    console.log('onSubmit values: ', values);

    this.displayloader = true;

    if (this.form.valid) {

      this._GeneralService.login(values, url)
        .subscribe((data: any) => {

          console.log('error Login data', data);

          console.log('error Login error.error.errorCode = ', data.errorCode);
          console.log('error Login error.error.licenseErrorCode = ', data.licenseErrorCode);
          console.log('error Login error.error.errorMessage = ', data.errorMessage)

          if (data.errorCode != 0) {
            this.resetSign();
            if (data.licenseErrMsg != undefined) {
              Swal('', data.licenseErrMsg, 'error');
            }
          }

          if (data.response.errorCode != undefined) {

            if (data.response.errorCode == 0) {
              this._GeneralService.saveMenu(data);
              this._GeneralService.saveUserDetails(data);
              this.loginSucc = true;
              setTimeout(() => {
                this.router.navigate(['./dashboard']);
              }, 50);
            }
          }

        },
          (error: any) => {

            console.log('error Login', error)

            console.log('error Login error.error.errorCode', error.error.errorCode);
            console.log('error Login error.error.licenseErrorCode', error.error.licenseErrorCode);
            console.log('error Login error.error.errorMessage', error.error.errorMessage)
            this.resetSign();
            if (error.error.licenseErrorCode === -1000) {

              this.licenseExpires(error.error.errorMessage)
              return;
            }

            Swal('', error.error.errorMessage, 'error');

          });
    }
  }

  licenseExpires(message) {

    let msg = `${message} or Click Renew License to renew it`
    Swal({

      title: '',
      text: msg,
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Renew License',
      confirmButtonColor: this.btnConfirm,
      cancelButtonText: 'Cancel',
      allowEscapeKey: false,
      allowOutsideClick: false

    }).then((result) => {

      if (result.value) {

        this.loginSucc = true;
        setTimeout(() => {
          this.router.navigate(['./license']);
          //this.router.navigate(['./dashboard']);
        }, 50);
      }
      else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    });
  }
  ngAfterViewInit() {
    this.settings.loadingSpinner = false;
  }

  resetSign() {

    this.btnlogtxt = 'SIGN IN';
    this.loginSucc = false;
    this.displayloader = false;

  }
}